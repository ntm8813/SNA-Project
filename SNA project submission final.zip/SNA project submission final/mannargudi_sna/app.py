"""
app.py  —  Mannargudi Tourism SNA  |  Streamlit entry point
===========================================================
Run:  streamlit run app.py
"""

import streamlit as st
import pandas as pd
import networkx as nx

# ── Page config ───────────────────────────────────────────────────────────────
st.set_page_config(
    page_title="Mannargudi Tourism SNA",
    page_icon="🛕",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ── Custom CSS ─────────────────────────────────────────────────────────────────
st.markdown(
    """
<style>
    @import url('https://fonts.googleapis.com/css2?family=Crimson+Pro:ital,wght@0,400;0,600;1,400&family=DM+Sans:wght@400;500&display=swap');

    html, body, [class*="css"] { font-family: 'DM Sans', sans-serif; }
    h1, h2, h3 { font-family: 'Crimson Pro', serif; }

    .stTabs [data-baseweb="tab-list"] { gap: 6px; }
    .stTabs [data-baseweb="tab"] {
        border-radius: 6px 6px 0 0;
        padding: 8px 18px;
        font-family: 'DM Sans', sans-serif;
        font-size: 14px;
    }

    .metric-card {
        background: linear-gradient(135deg, #FFFDF7 0%, #FFF6E8 100%);
        border: 1px solid #F0DFC0;
        border-radius: 10px;
        padding: 16px 20px;
        text-align: center;
    }
    .metric-card h3 { font-size: 1.6rem; margin: 0; color: #B8570A; }
    .metric-card p  { font-size: 0.75rem; color: #6B7280; margin: 0; }

    .day-card {
        background: white;
        border-left: 4px solid #E07B39;
        border-radius: 0 8px 8px 0;
        padding: 12px 16px;
        margin-bottom: 10px;
        box-shadow: 0 1px 4px rgba(0,0,0,0.07);
    }
    .day-card h4 { margin: 0 0 6px 0; color: #B8570A; font-family: 'Crimson Pro', serif; font-size: 1.1rem; }
    .day-card ul { margin: 0; padding-left: 20px; }
    .day-card li { font-size: 0.85rem; color: #374151; margin-bottom: 3px; }

    .sidebar-section { background: #FFFBF3; border-radius: 8px; padding: 12px; margin-bottom: 10px; }
    .stAlert { border-radius: 8px; }
</style>
""",
    unsafe_allow_html=True,
)

# ── Cached graph loading ───────────────────────────────────────────────────────
@st.cache_resource(show_spinner="Building tourism network…")
def load_graph():
    from utils.network_builder import build_graph, compute_metrics
    G = build_graph()
    metrics = compute_metrics(G)
    return G, metrics


G, metrics = load_graph()
node_attrs = dict(G.nodes(data=True))
node_label_map = {n: a.get("label", n) for n, a in node_attrs.items()}
label_node_map = {v: k for k, v in node_label_map.items()}

# ── Sidebar ────────────────────────────────────────────────────────────────────
with st.sidebar:
    st.image(
        "https://upload.wikimedia.org/wikipedia/commons/thumb/8/8d/Tamil_Nadu_outline_map.svg/200px-Tamil_Nadu_outline_map.svg.png",
        width=120,
    )
    st.title("🛕 Mannargudi SNA")
    st.caption("Social Network Analysis · Tourism Dispersion")

    st.divider()

    st.markdown("### 🗓️ Itinerary Builder")
    with st.container():
        from data.network_data import INTEREST_TAGS
        interests = st.multiselect(
            "Your interests",
            list(INTEREST_TAGS.keys()),
            default=["Spiritual / Pilgrimage"],
            help="Select one or more interest categories",
        )
        days = st.slider("Trip duration (days)", 1, 5, 2)
        start_label = st.selectbox(
            "Start from",
            list(node_label_map.values()),
            index=list(node_label_map.keys()).index("rajagopalaswamy_temple"),
        )

    generate_btn = st.button("✨ Generate Itinerary", use_container_width=True, type="primary")

    st.divider()
    st.markdown("### 🔍 Node Explorer")
    explore_label = st.selectbox(
        "Select a site",
        list(node_label_map.values()),
        key="explore_select",
    )

    st.divider()
    st.caption(
        "Data sources: Tamil Nadu Tourism Dept · ASI · HR&CE Dept · "
        "OpenStreetMap · Wikipedia · Lonely Planet"
    )

# ── Session state ──────────────────────────────────────────────────────────────
if "itinerary" not in st.session_state:
    st.session_state.itinerary = None

if generate_btn:
    from utils.network_builder import generate_itinerary
    start_node = label_node_map.get(start_label, "rajagopalaswamy_temple")
    st.session_state.itinerary = generate_itinerary(
        G, metrics, interests, days, start_node
    )

# ── Main content ───────────────────────────────────────────────────────────────
st.title("Mannargudi Tourism Network")
st.markdown(
    "**Social Network Analysis of Tourism Dispersion · Thiruvarur District, Tamil Nadu**  \n"
    "All data is based on publicly verifiable sources. No synthetic or invented data."
)

# ── KPI row ──────────────────────────────────────────────────────────────────
gs = metrics["graph_stats"]
c1, c2, c3, c4, c5 = st.columns(5)
kpis = [
    (gs["nodes"], "Tourism Sites"),
    (gs["edges"], "Network Connections"),
    (f"{gs['density']:.3f}", "Graph Density"),
    (gs["num_communities"], "Spatial Clusters"),
    (f"{gs['avg_clustering']:.3f}", "Avg Clustering"),
]
for col, (val, label) in zip([c1, c2, c3, c4, c5], kpis):
    col.markdown(
        f'<div class="metric-card"><h3>{val}</h3><p>{label}</p></div>',
        unsafe_allow_html=True,
    )

st.divider()

# ── Tabs ──────────────────────────────────────────────────────────────────────
tab1, tab2, tab3, tab4, tab5, tab6 = st.tabs([
    "🗺️ Network Map",
    "🌐 Geographic View",
    "📊 Metrics Dashboard",
    "🏘️ Communities",
    "🗓️ My Itinerary",
    "🔍 Site Explorer",
])

# ─── TAB 1: Network Map ───────────────────────────────────────────────────────
with tab1:
    from utils.visualizations import network_overview
    st.subheader("Tourism Network — Spring Layout")
    st.caption(
        "Node size ∝ betweenness centrality. Colour = site type. "
        "Edge width ∝ connection weight."
    )
    fig = network_overview(G, metrics, layout="spring")
    st.plotly_chart(fig, use_container_width=True)

    with st.expander("📖 How to read this graph"):
        st.markdown(
            """
**Nodes** represent real tourism sites in and around Mannargudi (Thiruvarur District, Tamil Nadu).
**Edges** connect sites that share:
- **Proximity** (≤5 km walkable / auto-rickshaw distance)
- **Road transport** (regular bus / taxi routes)
- **Thematic / pilgrimage** links (same religious tradition, UNESCO designation, festival circuit)
- **Ecological** links (same Ramsar wetland zone)

**Node size** reflects Betweenness Centrality — sites that act as gateways for travellers moving through the network.
"""
        )

# ─── TAB 2: Geographic View ───────────────────────────────────────────────────
with tab2:
    from utils.visualizations import geographic_map
    st.subheader("Geographic Distribution of Tourism Sites")
    st.caption("Node size ∝ PageRank. Uses actual GPS coordinates from OpenStreetMap.")

    col_path1, col_path2 = st.columns(2)
    with col_path1:
        src_label = st.selectbox("Path: From", list(node_label_map.values()), key="geo_src")
    with col_path2:
        tgt_label = st.selectbox(
            "Path: To",
            [l for l in node_label_map.values() if l != src_label],
            key="geo_tgt",
        )

    highlight = []
    if src_label and tgt_label:
        src_id = label_node_map.get(src_label)
        tgt_id = label_node_map.get(tgt_label)
        try:
            highlight = nx.shortest_path(G, src_id, tgt_id)
            hops = len(highlight) - 1
            total_dist = sum(
                G[highlight[i]][highlight[i + 1]].get("distance_km", 0)
                for i in range(hops)
            )
            st.info(
                f"🗺️ Shortest path: **{hops} hop(s)**, estimated distance: **{total_dist:.0f} km**  \n"
                f"Route: {' → '.join(node_label_map[n] for n in highlight)}"
            )
        except (nx.NetworkXNoPath, nx.NodeNotFound):
            st.warning("No direct path found between those sites.")

    fig = geographic_map(G, metrics, highlight_path=highlight)
    st.plotly_chart(fig, use_container_width=True)

# ─── TAB 3: Metrics Dashboard ─────────────────────────────────────────────────
with tab3:
    from utils.visualizations import centrality_bar, visitors_scatter
    st.subheader("Centrality Metrics Dashboard")

    centrality_choice = st.radio(
        "Select centrality measure",
        ["betweenness_centrality", "closeness_centrality",
         "eigenvector_centrality", "degree_centrality", "pagerank"],
        format_func=lambda x: x.replace("_", " ").title(),
        horizontal=True,
    )

    col_bar, col_scatter = st.columns([1, 1])
    with col_bar:
        st.plotly_chart(
            centrality_bar(metrics, centrality_choice), use_container_width=True
        )
    with col_scatter:
        st.plotly_chart(visitors_scatter(metrics), use_container_width=True)

    st.subheader("Full Centrality Table")
    display_df = metrics["centrality_df"][
        ["label", "type", "degree_centrality", "betweenness_centrality",
         "closeness_centrality", "eigenvector_centrality", "pagerank",
         "strength", "community", "visitor_annual"]
    ].copy()
    display_df.columns = [
        "Site", "Type", "Degree", "Betweenness", "Closeness",
        "Eigenvector", "PageRank", "Strength", "Community", "Visitors/yr"
    ]
    st.dataframe(
        display_df.style.format(
            {c: "{:.4f}" for c in ["Degree", "Betweenness", "Closeness", "Eigenvector", "PageRank"]}
        ).background_gradient(subset=["Betweenness"], cmap="YlOrRd"),
        use_container_width=True,
        height=420,
    )

    with st.expander("📐 Metric Definitions"):
        st.markdown(
            """
| Metric | Tourism Interpretation |
|--------|------------------------|
| **Degree Centrality** | How many direct connections a site has — a measure of raw connectivity |
| **Betweenness Centrality** | How often a site appears on shortest paths between others — identifies tourism gateways |
| **Closeness Centrality** | How quickly a site can reach all others — measures accessibility |
| **Eigenvector Centrality** | Importance weighted by neighbours' importance — identifies prestige hubs |
| **PageRank** | Probability a random tourist ends up at this site — overall visitation potential |
| **Strength** | Sum of all edge weights — total connection intensity |
"""
        )

# ─── TAB 4: Communities ───────────────────────────────────────────────────────
with tab4:
    from utils.visualizations import community_view
    st.subheader("Spatial Tourism Clusters (Louvain Community Detection)")
    st.caption(
        f"Modularity = {metrics['modularity']:.3f}. "
        "Higher modularity → more distinct geographical/thematic clustering."
    )
    fig = community_view(G, metrics)
    st.plotly_chart(fig, use_container_width=True)

    # Community breakdown table
    partition = metrics["community"]
    community_rows = []
    for node, comm in partition.items():
        attrs = node_attrs.get(node, {})
        community_rows.append({
            "Community": comm,
            "Site": attrs.get("label", node),
            "Type": attrs.get("type", ""),
            "Tags": ", ".join(attrs.get("tags", [])[:4]),
        })
    comm_df = pd.DataFrame(community_rows).sort_values(["Community", "Site"])

    for comm_id in sorted(comm_df["Community"].unique()):
        sub = comm_df[comm_df["Community"] == comm_id]
        from data.network_data import COMMUNITY_PALETTE  # noqa: F401 (kept for reference)
        color = ["#E07B39", "#4A90D9", "#6AB187", "#9B59B6",
                 "#F1C40F", "#E74C3C", "#1ABC9C", "#E67E22"][int(comm_id) % 8]
        st.markdown(
            f"<div style='border-left:4px solid {color}; padding:4px 12px; margin-bottom:6px;'>"
            f"<b>Community {comm_id}</b> &nbsp;|&nbsp; {len(sub)} sites"
            f"</div>",
            unsafe_allow_html=True,
        )
        st.dataframe(sub[["Site", "Type", "Tags"]].reset_index(drop=True), use_container_width=True, hide_index=True)

# ─── TAB 5: Itinerary ────────────────────────────────────────────────────────
with tab5:
    from utils.visualizations import itinerary_flow
    st.subheader("🗓️ Personalised Itinerary")

    if st.session_state.itinerary is None:
        st.info(
            "👈 Use the sidebar to set your interests and trip duration, "
            "then click **Generate Itinerary**."
        )
    else:
        itinerary = st.session_state.itinerary
        start_node_id = label_node_map.get(start_label, "rajagopalaswamy_temple")

        st.caption(
            f"Generated using network centrality + interest tag matching · "
            f"{days} day(s) · {len(interests)} interest category(ies)"
        )

        col_it, col_flow = st.columns([1, 2])
        with col_it:
            for day_idx, day_nodes in enumerate(itinerary):
                lines = ""
                for node in day_nodes:
                    attrs = node_attrs.get(node, {})
                    label = attrs.get("label", node)
                    ntype = attrs.get("type", "").replace("_", " ").title()
                    desc = attrs.get("description", "")[:90]
                    bc = metrics["betweenness_centrality"].get(node, 0)
                    lines += (
                        f"<li><b>{label}</b> <span style='color:#6B7280'>({ntype})</span><br>"
                        f"<span style='font-size:0.78rem;color:#6B7280'>{desc}…</span><br>"
                        f"<span style='font-size:0.75rem;color:#B8570A'>Gateway score: {bc:.3f}</span></li>"
                    )
                st.markdown(
                    f'<div class="day-card"><h4>Day {day_idx + 1}</h4><ul>{lines}</ul></div>',
                    unsafe_allow_html=True,
                )

            # Network explanation
            with st.expander("🔬 Why these sites?"):
                st.markdown(
                    """
The itinerary algorithm:
1. **Filters** candidate nodes by your interest tags (mapped to node tag attributes)
2. **Scores** each site: 35% Betweenness Centrality + 35% Eigenvector Centrality + 30% visitor volume
3. **Groups** top-scoring sites into days (3 sites/day), ensuring logical clustering

High-betweenness sites are prioritised because they act as **tourism gateways** — 
visiting them maximises your coverage of the network with minimum travel overhead.
"""
                )

        with col_flow:
            fig = itinerary_flow(G, itinerary, metrics)
            st.plotly_chart(fig, use_container_width=True)

        # Distance table
        st.subheader("Estimated Travel Information")
        travel_rows = []
        for day_nodes in itinerary:
            for i in range(len(day_nodes) - 1):
                u, v = day_nodes[i], day_nodes[i + 1]
                edge_data = G.get_edge_data(u, v, default={})
                travel_rows.append({
                    "From": node_label_map.get(u, u),
                    "To": node_label_map.get(v, v),
                    "Distance (km)": edge_data.get("distance_km", "indirect"),
                    "Connection Type": edge_data.get("type", "N/A").replace("_", " ").title(),
                    "Note": edge_data.get("reason", "—")[:80],
                })
        if travel_rows:
            st.dataframe(pd.DataFrame(travel_rows), use_container_width=True, hide_index=True)

# ─── TAB 6: Site Explorer ─────────────────────────────────────────────────────
with tab6:
    from utils.visualizations import radar_chart
    from utils.network_builder import get_node_info

    explore_node = label_node_map.get(explore_label, "rajagopalaswamy_temple")
    info = get_node_info(G, explore_node, metrics)

    st.subheader(f"🔍 {info.get('label', explore_node)}")

    col_info, col_radar = st.columns([2, 1])
    with col_info:
        st.markdown(
            f"**Type:** {info.get('type','').replace('_',' ').title()}  \n"
            f"**Historical Period:** {info.get('historical_period','')}  \n"
            f"**Significance:** {info.get('significance','').title()}  \n"
            f"**Annual Visitors (est.):** {info.get('visitor_annual', 0):,}  \n"
            f"**Community:** Cluster {info.get('community', '')}  \n"
            f"**Tags:** {', '.join(info.get('tags', []))}  \n"
            f"**Data Source:** {info.get('source','')}  \n\n"
            f"**Description:**  \n{info.get('description','')}"
        )

        st.markdown("#### SNA Metrics")
        mc1, mc2, mc3, mc4, mc5 = st.columns(5)
        for col, (k, v) in zip(
            [mc1, mc2, mc3, mc4, mc5],
            [
                ("Degree", info["degree"]),
                ("Betweenness", f"{info['betweenness_centrality']:.4f}"),
                ("Closeness", f"{info['closeness_centrality']:.4f}"),
                ("Eigenvector", f"{info['eigenvector_centrality']:.4f}"),
                ("PageRank", f"{info['pagerank']:.4f}"),
            ],
        ):
            col.metric(k, v)

    with col_radar:
        st.plotly_chart(radar_chart(info), use_container_width=True)

    # Neighbours table
    st.subheader("Connected Sites")
    nb_rows = []
    for nb in info["neighbors"]:
        edge_data = G.get_edge_data(explore_node, nb, default={})
        nb_rows.append({
            "Neighbour": node_label_map.get(nb, nb),
            "Connection Weight": edge_data.get("weight", ""),
            "Type": edge_data.get("type", "").replace("_", " ").title(),
            "Distance (km)": edge_data.get("distance_km", ""),
            "Reason": edge_data.get("reason", "")[:90],
            "Source": edge_data.get("source", ""),
        })
    if nb_rows:
        st.dataframe(
            pd.DataFrame(nb_rows).sort_values("Connection Weight", ascending=False),
            use_container_width=True,
            hide_index=True,
        )

    # Shortest paths from this node
    st.subheader("Shortest Paths from This Site")
    from utils.network_builder import get_shortest_paths
    paths = get_shortest_paths(G, explore_node, list(G.nodes()))
    path_rows = [
        {
            "Destination": node_label_map.get(tgt, tgt),
            "Hops": data["hops"],
            "Route": " → ".join(node_label_map.get(n, n) for n in data["path"]),
        }
        for tgt, data in paths.items()
        if data["hops"] < float("inf")
    ]
    path_df = pd.DataFrame(path_rows).sort_values("Hops")
    st.dataframe(path_df, use_container_width=True, hide_index=True, height=300)

# ── Footer ─────────────────────────────────────────────────────────────────────
st.divider()
st.caption(
    "⚠️ **Limitations:** Visitor estimates are approximate and sourced from district tourism reports. "
    "Edge weights reflect relative connection strength, not measured travel demand. "
    "Community detection results may vary with graph updates. "
    "This tool is for research and educational purposes only.  \n"
    "📜 **Ethics:** This project uses only publicly available, non-personal data. "
    "No private user data is collected or stored. Temple sensitivities are respected by "
    "focusing on factual historical and geographical information."
)
