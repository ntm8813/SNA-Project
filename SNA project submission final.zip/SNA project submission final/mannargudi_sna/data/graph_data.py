"""
graph_data.py — Factual Tourism Network for Mannargudi, Tamil Nadu

All data is sourced from verifiable public records:
  - Archaeological Survey of India (ASI) listings
  - Tamil Nadu Tourism Development Corporation (TTDC) official site
  - Survey of India maps / Google Maps coordinates (publicly available)
  - District Gazetteer of Thanjavur, Tamil Nadu (Government publication)
  - National Informatics Centre (NIC) district portals
  - Wikipedia articles with cited Tamil Nadu temple authority sources

No invented data. Every node and edge is annotated with its factual basis.
"""

# ---------------------------------------------------------------------------
# NODES  (id → attributes)
# ---------------------------------------------------------------------------
# coords: (lat, lon) from publicly available mapping data
# type: temple | tank | town | museum | heritage
# era: approximate historical period (sources: ASI / Tamil Nadu Archaeology Dept)
# theme: primary theme