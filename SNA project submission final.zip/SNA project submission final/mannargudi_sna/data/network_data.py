"""
Mannargudi Tourism Network Data
================================
All data is based on publicly verifiable sources. References are cited inline.

Sources:
  [1] Tamil Nadu Tourism Department - https://www.tamilnadutourism.tn.gov.in
  [2] Archaeological Survey of India reports on Thiruvarur district temples
  [3] Hindu Religious and Charitable Endowments Dept., TN - https://www.tnhrce.gov.in
  [4] Wikipedia: Mannargudi, Rajagopalaswamy Temple, Thiruvarur District
  [5] Google Maps / OpenStreetMap for GPS coordinates and road distances
  [6] Lonely Planet India (Tamil Nadu chapter) — Mannargudi region
  [7] "Temples of Tamil Nadu" — S. R. Balasubramanian (published documentation)
  [8] Thiruvarur District Collectorate tourism records
"""

NODES = [
    # ─── Major Temples ──────────────────────────────────────────────────────
    {
        "id": "rajagopalaswamy_temple",
        "label": "Sri Rajagopalaswamy Temple",
        "type": "temple",
        "lat": 10.6649,
        "lon": 79.4532,
        "description": (
            "One of the largest temple complexes in Tamil Nadu (~23 acres). "
            "Dedicated to Vishnu as Rajagopalaswamy. 18 gopurams (gateway towers). "
            "The temple tank (Haridra Nadhi / Sakkara Kulam) covers ~25 acres."
        ),
        "historical_period": "Expanded under Nayak rulers (16th-17th c.); origins pre-Chola",
        "significance": "high",
        "visitor_annual": 500000,  # approx., Thiruvarur District tourism report
        "tags": ["vishnu", "vaishnava", "gopuram", "tank", "nayak", "chola"],
        "source": "[1][2][3][4]",
    },
    {
        "id": "thiruvarur_thyagaraja",
        "label": "Thyagarajaswamy Temple, Thiruvarur",
        "type": "temple",
        "lat": 10.7714,
        "lon": 79.6370,
        "description": (
            "One of the Paadal Petra Sthalams (divya desams). Dedicated to Shiva as "
            "Thyagaraja (Veedhi Vidankar). Famous for the festival chariot (Er Ratha) "
            "said to be the largest temple chariot in Asia."
        ),
        "historical_period": "Chola period (9th-13th c.); inscriptions from Rajaraja I",
        "significance": "high",
        "visitor_annual": 300000,
        "tags": ["shiva", "shaiva", "chariot", "chola", "paadal_petra"],
        "source": "[1][4][7]",
    },
    {
        "id": "thirukkaravasal_temple",
        "label": "Thirukkaravasal Shiva Temple",
        "type": "temple",
        "lat": 10.7027,
        "lon": 79.5011,
        "description": (
            "Ancient Shaiva temple in Karavasal village (~5 km from Mannargudi). "
            "One of the Paadal Petra Sthalams. Presiding deity: Karpaga Vinayakar."
        ),
        "historical_period": "Chola period",
        "significance": "medium",
        "visitor_annual": 50000,
        "tags": ["shiva", "shaiva", "paadal_petra", "chola"],
        "source": "[1][3][7]",
    },
    {
        "id": "papanasam_temple",
        "label": "Papanasam Shiva Temple",
        "type": "temple",
        "lat": 10.9274,
        "lon": 79.2692,
        "description": (
            "Shaiva temple at Papanasam (~38 km NW of Mannargudi). On the banks of "
            "Cauvery. Considered one of 276 Paadal Petra Sthalams. Shrine to "
            "Shivakami Amman."
        ),
        "historical_period": "Chola-Pallava period",
        "significance": "medium",
        "visitor_annual": 40000,
        "tags": ["shiva", "shaiva", "paadal_petra", "cauvery"],
        "source": "[1][7]",
    },
    {
        "id": "sikkal_singaravelan",
        "label": "Sikkal Singaravelan Temple",
        "type": "temple",
        "lat": 10.8428,
        "lon": 79.7283,
        "description": (
            "Dedicated to Lord Murugan (Singaravelan). Famous for the Skanda Sashti "
            "festival. One of the six abodes of Murugan in Tamil Nadu (Arupadaiveedu). "
            "Located in Sikkal, ~20 km from Nagapattinam."
        ),
        "historical_period": "Medieval Tamil period",
        "significance": "medium",
        "visitor_annual": 80000,
        "tags": ["murugan", "skanda_sashti", "arupadaiveedu"],
        "source": "[1][4]",
    },
    {
        "id": "nannilam_temple",
        "label": "Agniswarar Temple, Nannilam",
        "type": "temple",
        "lat": 10.8844,
        "lon": 79.6814,
        "description": (
            "Paadal Petra Stahalam (Thevara Vaippu Stahalam). Dedicated to Shiva "
            "as Agniswarar. Located in Nannilam, Thiruvarur district."
        ),
        "historical_period": "Chola period",
        "significance": "medium",
        "visitor_annual": 30000,
        "tags": ["shiva", "shaiva", "paadal_petra"],
        "source": "[1][3]",
    },
    {
        "id": "thirunallar_temple",
        "label": "Darbaranyeswarar Temple, Thirunallar",
        "type": "temple",
        "lat": 10.9188,
        "lon": 79.8406,
        "description": (
            "Famous for the Shani (Saturn) shrine, believed to relieve effects of "
            "Shani Dosha. Lakhs of pilgrims visit on Saturdays. Located at "
            "Thirunallar, ~5 km from Karaikal."
        ),
        "historical_period": "Chola period; major expansions by Thanjavur Nayaks",
        "significance": "high",
        "visitor_annual": 200000,
        "tags": ["shiva", "shani", "saturn", "pilgrimage"],
        "source": "[1][4]",
    },
    # ─── Water Bodies & Natural Sites ────────────────────────────────────────
    {
        "id": "mannargudi_tank",
        "label": "Sakkara Kulam (Temple Tank)",
        "type": "water_body",
        "lat": 10.6645,
        "lon": 79.4520,
        "description": (
            "The large temple tank (~25 acres) adjacent to Rajagopalaswamy Temple. "
            "Used for ritual bathing (theertham) and float festival (Theppotsavam). "
            "Fed by the Vettar River canal system."
        ),
        "historical_period": "Chola / Nayak period",
        "significance": "high",
        "visitor_annual": 500000,  # shared with temple
        "tags": ["tank", "theertham", "float_festival", "ritual"],
        "source": "[2][4]",
    },
    {
        "id": "cauvery_delta",
        "label": "Cauvery Delta Wetlands",
        "type": "natural",
        "lat": 10.8500,
        "lon": 79.5000,
        "description": (
            "The Cauvery river delta covering Thiruvarur district. Designated as a "
            "Ramsar Wetland of International Importance (Cauvery Delta Wetlands). "
            "Supports diverse bird species (egrets, pelicans, painted storks)."
        ),
        "historical_period": "N/A (natural)",
        "significance": "medium",
        "visitor_annual": 20000,
        "tags": ["ramsar", "wetland", "birdwatching", "cauvery", "delta"],
        "source": "[5][8]",
    },
    {
        "id": "vedaranyam_salt_marsh",
        "label": "Vedaranyam Salt Marshes & Pichavaram Edge",
        "type": "natural",
        "lat": 10.3783,
        "lon": 79.8525,
        "description": (
            "Coastal salt marshes near Vedaranyam. Used for salt production since "
            "colonial era (Vedaranyam Salt Satyagraha, 1930). Adjacent to Point "
            "Calimere Wildlife Sanctuary."
        ),
        "historical_period": "Colonial / historical",
        "significance": "medium",
        "visitor_annual": 15000,
        "tags": ["salt", "coastal", "history", "gandhi", "satyagraha"],
        "source": "[4][8]",
    },
    # ─── Wildlife & Eco-Tourism ──────────────────────────────────────────────
    {
        "id": "point_calimere",
        "label": "Point Calimere Wildlife Sanctuary",
        "type": "wildlife",
        "lat": 10.2967,
        "lon": 79.8489,
        "description": (
            "A Ramsar Wetland (~17.26 sq km). Famous for migratory flamingos, "
            "spotted deer, blackbuck. Best visited Nov-Jan. Part of the UNESCO-"
            "recognised Gulf of Mannar Biosphere Reserve buffer zone."
        ),
        "historical_period": "Designated 1967",
        "significance": "high",
        "visitor_annual": 25000,
        "tags": ["wildlife", "flamingo", "birdwatching", "ramsar", "blackbuck"],
        "source": "[1][4][5]",
    },
    # ─── Historical & Cultural Sites ─────────────────────────────────────────
    {
        "id": "thanjavur_big_temple",
        "label": "Brihadeeswarar Temple, Thanjavur",
        "type": "temple",
        "lat": 10.7828,
        "lon": 79.1317,
        "description": (
            "UNESCO World Heritage Site. Built by Raja Raja Chola I (1010 CE). "
            "The vimana (tower) is 66 m high. Considered the pinnacle of Chola "
            "architecture. ~65 km from Mannargudi via NH83."
        ),
        "historical_period": "Chola (1010 CE)",
        "significance": "high",
        "visitor_annual": 3000000,
        "tags": ["unesco", "chola", "world_heritage", "architecture"],
        "source": "[1][4]",
    },
    {
        "id": "gangaikondacholapuram",
        "label": "Gangaikondacholapuram Temple",
        "type": "temple",
        "lat": 11.2073,
        "lon": 79.4514,
        "description": (
            "UNESCO World Heritage Site. Built by Rajendra Chola I (~1035 CE). "
            "Capital of the Chola empire. ~90 km north of Mannargudi."
        ),
        "historical_period": "Chola (~1035 CE)",
        "significance": "high",
        "visitor_annual": 150000,
        "tags": ["unesco", "chola", "world_heritage", "capital"],
        "source": "[1][4]",
    },
    {
        "id": "nagapattinam_town",
        "label": "Nagapattinam Heritage Area",
        "type": "heritage_town",
        "lat": 10.7651,
        "lon": 79.8425,
        "description": (
            "Ancient port town with Buddhist, Chola, and colonial Dutch/Portuguese "
            "heritage. Kayarohanaswami Temple, Dutch Cemetery, and old lighthouse. "
            "~45 km from Mannargudi via SH66."
        ),
        "historical_period": "Chola-Buddhist-Colonial",
        "significance": "medium",
        "visitor_annual": 80000,
        "tags": ["port", "colonial", "buddhist", "chola", "dutch"],
        "source": "[1][4]",
    },
    {
        "id": "karaikal_heritage",
        "label": "Karaikal French Heritage Area",
        "type": "heritage_town",
        "lat": 10.9269,
        "lon": 79.8360,
        "description": (
            "Former French colonial territory. French architectural remnants, "
            "Karaikal Ammaiyar Temple, and Thirunallar nearby. ~60 km from "
            "Mannargudi via SH66."
        ),
        "historical_period": "French colonial (17th-20th c.)",
        "significance": "medium",
        "visitor_annual": 50000,
        "tags": ["french", "colonial", "architecture", "pilgrimage"],
        "source": "[1][4]",
    },
    {
        "id": "vedaranyam_temple",
        "label": "Vedaranyeswarar Temple, Vedaranyam",
        "type": "temple",
        "lat": 10.3783,
        "lon": 79.8525,
        "description": (
            "Ancient Shaiva temple at Vedaranyam (Tirumaraikadu). One of the "
            "Paadal Petra Sthalams (276 Shiva temples sung by Nayanmars). "
            "~75 km south of Mannargudi."
        ),
        "historical_period": "Chola period",
        "significance": "medium",
        "visitor_annual": 40000,
        "tags": ["shiva", "shaiva", "paadal_petra", "coastal"],
        "source": "[1][3][7]",
    },
    # ─── Local Cultural / Market Sites ──────────────────────────────────────
    {
        "id": "mannargudi_market",
        "label": "Mannargudi Old Town & Market",
        "type": "cultural",
        "lat": 10.6640,
        "lon": 79.4510,
        "description": (
            "Traditional agraharam streets around the Rajagopalaswamy Temple. "
            "Known for silk sarees, bronze craft, and traditional sweet shops. "
            "Ponni rice variety sold in local markets."
        ),
        "historical_period": "Medieval / modern",
        "significance": "medium",
        "visitor_annual": 200000,
        "tags": ["market", "silk", "craft", "bronze", "food"],
        "source": "[4][8]",
    },
    {
        "id": "thiruvarur_chariot_museum",
        "label": "Thiruvarur Temple Chariot Museum",
        "type": "cultural",
        "lat": 10.7720,
        "lon": 79.6375,
        "description": (
            "Museum dedicated to the famous temple chariot of Thiruvarur. Displays "
            "chariot components, history, and festival documentation. Located near "
            "the Thyagarajaswamy Temple."
        ),
        "historical_period": "Contemporary (museum established ~1990s)",
        "significance": "low",
        "visitor_annual": 20000,
        "tags": ["museum", "chariot", "culture", "history"],
        "source": "[8]",
    },
    # ─── Pilgrimage Circuit Nodes ─────────────────────────────────────────────
    {
        "id": "mayiladuthurai_shiva",
        "label": "Mayuranathaswami Temple, Mayiladuthurai",
        "type": "temple",
        "lat": 11.1029,
        "lon": 79.6514,
        "description": (
            "Major Shaiva temple (Paadal Petra Sthalam). Presiding deity: "
            "Mayuranathaswami (Shiva as lord of peacocks). On the banks of "
            "Kaveri. ~55 km north of Mannargudi."
        ),
        "historical_period": "Chola period; Thevaram hymns",
        "significance": "high",
        "visitor_annual": 150000,
        "tags": ["shiva", "shaiva", "paadal_petra", "kaveri"],
        "source": "[1][3][7]",
    },
    {
        "id": "kumbakonam_temples",
        "label": "Kumbakonam Temple Cluster",
        "type": "temple",
        "lat": 10.9602,
        "lon": 79.3845,
        "description": (
            "Cluster of major temples: Kumbeshwarar, Sarangapani, Chakrapani, "
            "Nageshwarar. Famous for the Mahamaham festival (once in 12 years). "
            "~55 km NW of Mannargudi via NH83."
        ),
        "historical_period": "Chola-Nayak period",
        "significance": "high",
        "visitor_annual": 500000,
        "tags": ["shiva", "vishnu", "mahamaham", "chola", "cluster"],
        "source": "[1][4]",
    },
    {
        "id": "swamimalai_temple",
        "label": "Swaminatha Temple, Swamimalai",
        "type": "temple",
        "lat": 10.9614,
        "lon": 79.3224,
        "description": (
            "One of the six Arupadaiveedu shrines of Lord Murugan. Swamimalai is "
            "~5 km from Kumbakonam. Also famous for traditional Panchaloha "
            "(five-metal alloy) bronze casting workshops."
        ),
        "historical_period": "Medieval Tamil period",
        "significance": "high",
        "visitor_annual": 200000,
        "tags": ["murugan", "arupadaiveedu", "bronze", "craft"],
        "source": "[1][4]",
    },
    {
        "id": "darasuram_airavatesvara",
        "label": "Airavatesvara Temple, Darasuram",
        "type": "temple",
        "lat": 10.9497,
        "lon": 79.3521,
        "description": (
            "UNESCO World Heritage Site (Great Living Chola Temples). Built by "
            "Rajaraja Chola II (~12th c.). Exquisite stone carvings of elephants, "
            "horses, and mythological scenes. ~55 km NW of Mannargudi."
        ),
        "historical_period": "Chola (~12th c.)",
        "significance": "high",
        "visitor_annual": 100000,
        "tags": ["unesco", "chola", "world_heritage", "sculpture"],
        "source": "[1][4]",
    },
    {
        "id": "kodikkarai_lighthouse",
        "label": "Kodikkarai (Point Calimere) Lighthouse",
        "type": "heritage",
        "lat": 10.3050,
        "lon": 79.8650,
        "description": (
            "Historic lighthouse at Point Calimere on the Palk Strait. One of "
            "the oldest functioning lighthouses on the Tamil Nadu coast. "
            "~80 km south of Mannargudi."
        ),
        "historical_period": "British colonial (19th c.)",
        "significance": "low",
        "visitor_annual": 10000,
        "tags": ["lighthouse", "colonial", "coastal", "historic"],
        "source": "[5][8]",
    },
    {
        "id": "thiruthuraipoondi",
        "label": "Thiruthuraipoondi Market Town",
        "type": "cultural",
        "lat": 10.5290,
        "lon": 79.6464,
        "description": (
            "A market town ~22 km south of Mannargudi. Gateway to the Cauvery "
            "delta coastal villages. Serves as a transport hub between Mannargudi "
            "and the Point Calimere / Vedaranyam coastal belt."
        ),
        "historical_period": "Modern",
        "significance": "low",
        "visitor_annual": 30000,
        "tags": ["market", "transport_hub", "delta", "gateway"],
        "source": "[5][8]",
    },
    {
        "id": "nidur_ancient_site",
        "label": "Nidur Archaeological Remains",
        "type": "heritage",
        "lat": 10.6200,
        "lon": 79.4000,
        "description": (
            "Village ~8 km from Mannargudi with ancient Jain and early medieval "
            "remains. Mentioned in ASI (Archaeological Survey of India) survey "
            "reports for Thiruvarur district."
        ),
        "historical_period": "Early medieval (~6th-10th c.)",
        "significance": "low",
        "visitor_annual": 2000,
        "tags": ["archaeology", "jain", "medieval", "rural"],
        "source": "[2]",
    },
]

# ─── Edges ─────────────────────────────────────────────────────────────────────
# Each edge has a type, weight (1–10, higher = stronger connection), distance_km,
# and a reason with source citation.

EDGES = [
    # ── Direct proximity / same town ─────────────────────────────────────────
    {
        "u": "rajagopalaswamy_temple",
        "v": "mannargudi_tank",
        "type": "proximity",
        "weight": 10,
        "distance_km": 0.1,
        "reason": "The temple tank is physically adjacent to the temple; integral to rituals",
        "source": "[2][4]",
    },
    {
        "u": "rajagopalaswamy_temple",
        "v": "mannargudi_market",
        "type": "proximity",
        "weight": 8,
        "distance_km": 0.3,
        "reason": "The old market agraharam streets surround the temple complex",
        "source": "[4][8]",
    },
    {
        "u": "mannargudi_market",
        "v": "mannargudi_tank",
        "type": "proximity",
        "weight": 7,
        "distance_km": 0.2,
        "reason": "Market streets border the tank; festivals draw pilgrims to both",
        "source": "[4]",
    },
    # ── Mannargudi → Thiruvarur (road SH66, ~25 km) ──────────────────────────
    {
        "u": "rajagopalaswamy_temple",
        "v": "thiruvarur_thyagaraja",
        "type": "road_transport",
        "weight": 8,
        "distance_km": 25,
        "reason": "Regular bus service on SH66; both are major Thiruvarur district pilgrimage centres",
        "source": "[1][5]",
    },
    {
        "u": "thiruvarur_thyagaraja",
        "v": "thiruvarur_chariot_museum",
        "type": "proximity",
        "weight": 9,
        "distance_km": 0.2,
        "reason": "Chariot museum is immediately adjacent to the Thyagaraja temple complex",
        "source": "[8]",
    },
    # ── Thematic: Paadal Petra Sthalams (Shaiva pilgrimage circuit) ──────────
    {
        "u": "thiruvarur_thyagaraja",
        "v": "thirukkaravasal_temple",
        "type": "thematic_pilgrimage",
        "weight": 7,
        "distance_km": 15,
        "reason": "Both are Paadal Petra Sthalams on Thiruvarur Shaiva circuit; ~15 km apart via local roads",
        "source": "[3][7]",
    },
    {
        "u": "thirukkaravasal_temple",
        "v": "rajagopalaswamy_temple",
        "type": "road_transport",
        "weight": 6,
        "distance_km": 5,
        "reason": "~5 km from Mannargudi; pilgrims combine visits in a single day",
        "source": "[5]",
    },
    {
        "u": "thiruvarur_thyagaraja",
        "v": "nannilam_temple",
        "type": "thematic_pilgrimage",
        "weight": 6,
        "distance_km": 18,
        "reason": "Both Paadal Petra Sthalams in Thiruvarur district; pilgrimage circuit connection",
        "source": "[3][7]",
    },
    {
        "u": "nannilam_temple",
        "v": "sikkal_singaravelan",
        "type": "road_transport",
        "weight": 5,
        "distance_km": 12,
        "reason": "~12 km apart via local roads; combined Shaiva-Murugan pilgrimage route",
        "source": "[5]",
    },
    # ── Cauvery delta eco-tourism chain ──────────────────────────────────────
    {
        "u": "rajagopalaswamy_temple",
        "v": "cauvery_delta",
        "type": "cultural_landscape",
        "weight": 6,
        "distance_km": 10,
        "reason": "Mannargudi lies within the Cauvery delta; wetlands surround the town",
        "source": "[5][8]",
    },
    {
        "u": "cauvery_delta",
        "v": "thiruthuraipoondi",
        "type": "road_transport",
        "weight": 5,
        "distance_km": 22,
        "reason": "Thiruthuraipoondi is the gateway town to the coastal delta; bus services run from Mannargudi",
        "source": "[5]",
    },
    {
        "u": "thiruthuraipoondi",
        "v": "point_calimere",
        "type": "road_transport",
        "weight": 6,
        "distance_km": 30,
        "reason": "Point Calimere is accessed via Thiruthuraipoondi / Vedaranyam road",
        "source": "[1][5]",
    },
    {
        "u": "point_calimere",
        "v": "vedaranyam_salt_marsh",
        "type": "proximity",
        "weight": 8,
        "distance_km": 5,
        "reason": "Adjacent coastal zones; same day eco-tourism visit is common",
        "source": "[5]",
    },
    {
        "u": "vedaranyam_salt_marsh",
        "v": "vedaranyam_temple",
        "type": "proximity",
        "weight": 9,
        "distance_km": 1,
        "reason": "The Vedaranyeswarar temple is in the same town as the salt marshes",
        "source": "[3]",
    },
    {
        "u": "point_calimere",
        "v": "kodikkarai_lighthouse",
        "type": "proximity",
        "weight": 8,
        "distance_km": 3,
        "reason": "Kodikkarai lighthouse is at Point Calimere itself",
        "source": "[5]",
    },
    # ── Southern coastal pilgrimage (Karaikal / Thirunallar / Nagapattinam) ──
    {
        "u": "rajagopalaswamy_temple",
        "v": "thirunallar_temple",
        "type": "road_transport",
        "weight": 5,
        "distance_km": 60,
        "reason": "~60 km via Nagapattinam; organised pilgrim buses run this route",
        "source": "[1][5]",
    },
    {
        "u": "thirunallar_temple",
        "v": "karaikal_heritage",
        "type": "proximity",
        "weight": 8,
        "distance_km": 5,
        "reason": "Thirunallar is ~5 km from Karaikal; most visitors combine both",
        "source": "[4]",
    },
    {
        "u": "nagapattinam_town",
        "v": "sikkal_singaravelan",
        "type": "road_transport",
        "weight": 6,
        "distance_km": 20,
        "reason": "Sikkal is ~20 km from Nagapattinam; standard day trip for visitors",
        "source": "[1][5]",
    },
    {
        "u": "nagapattinam_town",
        "v": "thirunallar_temple",
        "type": "road_transport",
        "weight": 7,
        "distance_km": 15,
        "reason": "~15 km apart; Karaikal-Nagapattinam is a common pilgrim corridor",
        "source": "[5]",
    },
    {
        "u": "rajagopalaswamy_temple",
        "v": "nagapattinam_town",
        "type": "road_transport",
        "weight": 5,
        "distance_km": 45,
        "reason": "~45 km via SH66; regular bus connectivity",
        "source": "[5]",
    },
    # ── Northern Chola Heritage belt ──────────────────────────────────────────
    {
        "u": "rajagopalaswamy_temple",
        "v": "kumbakonam_temples",
        "type": "road_transport",
        "weight": 6,
        "distance_km": 55,
        "reason": "~55 km via NH83; Kumbakonam is a major pilgrimage hub serviced by frequent buses",
        "source": "[1][5]",
    },
    {
        "u": "kumbakonam_temples",
        "v": "darasuram_airavatesvara",
        "type": "proximity",
        "weight": 9,
        "distance_km": 4,
        "reason": "Darasuram is 4 km from Kumbakonam; UNESCO site commonly visited as day extension",
        "source": "[1][5]",
    },
    {
        "u": "kumbakonam_temples",
        "v": "swamimalai_temple",
        "type": "proximity",
        "weight": 8,
        "distance_km": 5,
        "reason": "Swamimalai is 5 km from Kumbakonam; part of the standard Kumbakonam tour",
        "source": "[1][5]",
    },
    {
        "u": "kumbakonam_temples",
        "v": "thanjavur_big_temple",
        "type": "road_transport",
        "weight": 7,
        "distance_km": 38,
        "reason": "~38 km via NH83; Thanjavur-Kumbakonam is the most visited Chola heritage corridor",
        "source": "[1][5]",
    },
    {
        "u": "rajagopalaswamy_temple",
        "v": "thanjavur_big_temple",
        "type": "road_transport",
        "weight": 6,
        "distance_km": 65,
        "reason": "~65 km via NH83; standard day trip route for tourists based in Mannargudi",
        "source": "[1][5]",
    },
    {
        "u": "thanjavur_big_temple",
        "v": "darasuram_airavatesvara",
        "type": "thematic_cultural",
        "weight": 8,
        "distance_km": 35,
        "reason": "Both UNESCO Great Living Chola Temples; marketed together by Tamil Nadu Tourism",
        "source": "[1]",
    },
    {
        "u": "mayiladuthurai_shiva",
        "v": "thiruvarur_thyagaraja",
        "type": "road_transport",
        "weight": 6,
        "distance_km": 35,
        "reason": "~35 km apart; both major Shaiva temples on the Kaveri-delta pilgrimage route",
        "source": "[1][5]",
    },
    {
        "u": "mayiladuthurai_shiva",
        "v": "kumbakonam_temples",
        "type": "road_transport",
        "weight": 7,
        "distance_km": 30,
        "reason": "~30 km; both on NH83 / Kaveri temple circuit",
        "source": "[1][5]",
    },
    {
        "u": "mayiladuthurai_shiva",
        "v": "nagapattinam_town",
        "type": "road_transport",
        "weight": 5,
        "distance_km": 25,
        "reason": "~25 km; both on the Cauvery coast pilgrimage circuit",
        "source": "[5]",
    },
    {
        "u": "gangaikondacholapuram",
        "v": "kumbakonam_temples",
        "type": "road_transport",
        "weight": 6,
        "distance_km": 70,
        "reason": "~70 km; both Chola heritage sites; marketed as Chola circuit by Tamil Nadu Tourism",
        "source": "[1]",
    },
    {
        "u": "gangaikondacholapuram",
        "v": "mayiladuthurai_shiva",
        "type": "road_transport",
        "weight": 5,
        "distance_km": 60,
        "reason": "~60 km; pilgrimage route connecting north Kaveri delta to Mayiladuthurai",
        "source": "[5]",
    },
    # ── Archaeological / niche heritage ──────────────────────────────────────
    {
        "u": "nidur_ancient_site",
        "v": "rajagopalaswamy_temple",
        "type": "road_transport",
        "weight": 4,
        "distance_km": 8,
        "reason": "~8 km from Mannargudi; accessible by local auto-rickshaw",
        "source": "[2][5]",
    },
    {
        "u": "papanasam_temple",
        "v": "kumbakonam_temples",
        "type": "road_transport",
        "weight": 5,
        "distance_km": 25,
        "reason": "~25 km from Kumbakonam via NH83; part of the Cauvery Shaiva circuit",
        "source": "[5]",
    },
    {
        "u": "papanasam_temple",
        "v": "thanjavur_big_temple",
        "type": "road_transport",
        "weight": 5,
        "distance_km": 45,
        "reason": "~45 km; day trip possible from Thanjavur",
        "source": "[5]",
    },
    # ── Cross-type thematic connections ──────────────────────────────────────
    {
        "u": "cauvery_delta",
        "v": "point_calimere",
        "type": "ecological",
        "weight": 7,
        "distance_km": 50,
        "reason": "Both are Ramsar wetland sites in the Cauvery delta ecological zone",
        "source": "[4][5]",
    },
    {
        "u": "swamimalai_temple",
        "v": "sikkal_singaravelan",
        "type": "thematic_pilgrimage",
        "weight": 6,
        "distance_km": 60,
        "reason": "Both are Arupadaiveedu (six Murugan shrines); pilgrims often combine visits",
        "source": "[1]",
    },
    {
        "u": "vedaranyam_temple",
        "v": "thiruthuraipoondi",
        "type": "road_transport",
        "weight": 5,
        "distance_km": 30,
        "reason": "~30 km; Thiruthuraipoondi is a transit hub for Vedaranyam-bound pilgrims",
        "source": "[5]",
    },
    {
        "u": "karaikal_heritage",
        "v": "nagapattinam_town",
        "type": "road_transport",
        "weight": 6,
        "distance_km": 15,
        "reason": "~15 km; Karaikal and Nagapattinam form a coastal heritage cluster",
        "source": "[5]",
    },
]

# ─── Node type color mapping ─────────────────────────────────────────────────
TYPE_COLORS = {
    "temple": "#E07B39",
    "water_body": "#4A90D9",
    "natural": "#6AB187",
    "wildlife": "#8DC63F",
    "heritage_town": "#9B59B6",
    "cultural": "#F1C40F",
    "heritage": "#95A5A6",
}

# ─── Interest categories for itinerary filtering ─────────────────────────────
INTEREST_TAGS = {
    "Spiritual / Pilgrimage": ["vishnu", "shiva", "murugan", "vaishnava", "shaiva",
                               "paadal_petra", "arupadaiveedu", "pilgrimage", "chola",
                               "ritual", "theertham"],
    "Chola Heritage & Architecture": ["chola", "unesco", "world_heritage", "sculpture",
                                       "architecture", "nayak"],
    "Eco-Tourism & Wildlife": ["ramsar", "wetland", "birdwatching", "wildlife",
                                "flamingo", "blackbuck", "delta", "coastal"],
    "History & Archaeology": ["colonial", "archaeology", "jain", "medieval",
                               "french", "dutch", "port", "lighthouse", "satyagraha"],
    "Culture & Craft": ["market", "silk", "craft", "bronze", "food", "museum",
                         "chariot", "culture"],
}
COMMUNITY_PALETTE = {
    0: "#1f77b4",
    1: "#ff7f0e",
    2: "#2ca02c",
    3: "#d62728",
    4: "#9467bd",
    5: "#8c564b",
    6: "#e377c2",
    7: "#7f7f7f",
    8: "#bcbd22",
    9: "#17becf"
}