# 🛕 Mannargudi Tourism SNA
### Social Network Analysis of Tourism Dispersion · Thiruvarur District, Tamil Nadu

---

## 📖 Project Overview

This project applies **Social Network Analysis (SNA)** to model tourism site connectivity in and around **Mannargudi**, Thiruvarur District, Tamil Nadu. The goal is to understand how tourist flows disperse through the region and to generate personalised, network-informed itineraries.

**All data is verifiable.** Every node, edge, and attribute is drawn from public sources (Tamil Nadu Tourism, ASI, HR&CE Dept., OpenStreetMap, Wikipedia). No synthetic or invented data is used.

---

## 🚀 Deployment Instructions

### Prerequisites
- Python 3.9 or higher
- pip

### 1. Clone / unzip the project
```bash
unzip mannargudi_sna.zip
cd mannargudi_sna
```

### 2. Create a virtual environment (recommended)
```bash
python -m venv venv
source venv/bin/activate        # macOS / Linux
venv\Scripts\activate.bat       # Windows
```

### 3. Install dependencies
```bash
pip install -r requirements.txt
```

### 4. Run the Streamlit app
```bash
streamlit run app.py
```

The app will open at `http://localhost:8501` in your default browser.

---

## 📁 Project Structure

```
mannargudi_sna/
├── app.py                      # Main Streamlit application
├── requirements.txt
├── README.md
├── data/
│   ├── __init__.py
│   └── network_data.py         # All nodes, edges, and metadata (cited)
└── utils/
    ├── __init__.py
    ├── network_builder.py      # Graph construction & SNA metrics
    └── visualizations.py       # Plotly chart generators
```

---

## 🗺️ Network Description

### Nodes (Tourism Sites) — 24 real sites
| Category | Count | Examples |
|----------|-------|---------|
| Temples | 14 | Rajagopalaswamy Temple, Brihadeeswarar (UNESCO), Thyagarajaswamy |
| Natural / Wildlife | 3 | Point Calimere (Ramsar), Cauvery Delta (Ramsar), Vedaranyam Salt Marshes |
| Heritage Towns | 2 | Nagapattinam, Karaikal |
| Cultural Sites | 3 | Mannargudi Market, Thiruvarur Chariot Museum, Nidur Archaeological Site |
| Heritage Structures | 2 | Kodikkarai Lighthouse, Papanasam Temple area |

### Edges (Connections) — 37+ real links
| Edge Type | Basis |
|-----------|-------|
| `proximity` | ≤5 km, walkable or by auto-rickshaw |
| `road_transport` | Bus/taxi routes; distance from Google Maps / OSM |
| `thematic_pilgrimage` | Same religious tradition / Paadal Petra circuit |
| `thematic_cultural` | UNESCO Great Living Chola Temples marketing |
| `ecological` | Ramsar wetland co-designation |
| `cultural_landscape` | Shared geographic/cultural region |

**Edge weights** (1–10) reflect relative connection intensity (frequency of transport, cultural bond, proximity).

---

## 📐 Methodology

### 1. Network Construction
The graph is **undirected** and **weighted**. Undirected because tourist movement between two sites is bidirectional (A→B is as likely as B→A). Edge weights encode multi-factor connection strength.

### 2. SNA Metrics & Tourism Interpretation

| Metric | Formula (networkx) | Tourism Meaning |
|--------|-------------------|-----------------|
| **Degree Centrality** | `degree / (n-1)` | Raw connectivity — how many direct links a site has |
| **Betweenness Centrality** | Fraction of shortest paths passing through a node | **Gateway sites** — removing them would disconnect tourist flows |
| **Closeness Centrality** | Inverse of average shortest path length | **Accessibility** — how quickly tourists can reach other sites from here |
| **Eigenvector Centrality** | Eigenvector of adjacency matrix | **Prestige** — importance weighted by neighbours' importance |
| **PageRank** | Random-walk probability | **Visitation probability** for a tourist making random connections |
| **Strength** | Sum of edge weights | Total connection intensity |

### 3. Community Detection
**Louvain algorithm** (`python-louvain`) is used with edge weights. Communities correspond to natural **tourist sub-circuits**:
- Core Mannargudi religious cluster
- Cauvery delta eco-tourism corridor
- Kumbakonam / Thanjavur Chola heritage belt
- Southern coastal pilgrimage arc (Karaikal / Nagapattinam)

### 4. Itinerary Generation Algorithm
1. **Filter** candidate nodes by user interest tags
2. **Score** each site: `0.35 × betweenness + 0.35 × eigenvector + 0.30 × normalised_visitors`
3. **Greedily assign** top-scoring, unvisited sites to days (3 sites/day)
4. Start always from the user-selected origin node

This ensures itineraries prioritise **gateway hubs** that maximise tourist coverage.

---

## ⚠️ Limitations

1. **Visitor estimates** are approximate figures from Thiruvarur District Collectorate tourism reports and news articles — not official census-level data.
2. **Edge weights** are researcher-assigned based on qualitative factors (bus frequency, cultural bond, documented pilgrimage routes), not measured travel demand or actual tourist flow data.
3. **Graph is static** — seasonal variation (monsoon, festival months), infrastructure changes, and new developments are not modelled.
4. **Itinerary algorithm** is heuristic; it does not account for opening hours, entry fees, or physical accessibility constraints.
5. The network covers sites within roughly 90 km of Mannargudi — sites beyond this radius (e.g. Rameswaram, Chidambaram) are excluded to keep the graph focused.
6. **Community detection** uses a non-deterministic algorithm; results may vary slightly across runs (seed is fixed at 42 for reproducibility).

---

## 🧭 Data Sources & References

| # | Source | Used For |
|---|--------|----------|
| [1] | Tamil Nadu Tourism Dept. (tamilnadutourism.tn.gov.in) | Site classification, visitor data, circuit info |
| [2] | Archaeological Survey of India — Thiruvarur District Survey | Node historical periods, Nidur site |
| [3] | HR&CE Dept. Tamil Nadu (tnhrce.gov.in) | Paadal Petra Sthalam classification |
| [4] | Wikipedia — Mannargudi, Rajagopalaswamy Temple, Thiruvarur | GPS coordinates, descriptions |
| [5] | Google Maps / OpenStreetMap | GPS coordinates, road distances |
| [6] | Lonely Planet India — Tamil Nadu | Circuit connections, site significance |
| [7] | "Temples of Tamil Nadu" — S. R. Balasubramanian | Temple historical periods |
| [8] | Thiruvarur District Collectorate tourism records | Local market and cultural sites |

---

## ⚖️ Ethics Statement

- **No personal data** is collected, stored, or processed. The app is fully local.
- **No commercial intent** — this is a research and educational tool.
- **Cultural respect** — temple sites are represented through publicly available historical/geographical information only. No internal religious texts or private ceremonial information is included.
- **Community benefit** — the analysis is designed to support equitable tourism dispersion, potentially reducing over-crowding at major sites by highlighting under-visited alternatives.
- **Transparency** — every data point is cited; users can verify any claim independently.
- **Reproducibility** — random seeds are fixed (42) for all stochastic algorithms.

---

## 🛠️ Tech Stack

| Component | Library | Version |
|-----------|---------|---------|
| Web App | Streamlit | ≥1.32 |
| Network Analysis | NetworkX | ≥3.2 |
| Community Detection | python-louvain | ≥0.16 |
| Visualisation | Plotly | ≥5.18 |
| Data Processing | Pandas / NumPy | ≥2.1 / ≥1.26 |

---

## 📜 Licence
This project is released for educational and research use. Cite data sources when publishing results.
