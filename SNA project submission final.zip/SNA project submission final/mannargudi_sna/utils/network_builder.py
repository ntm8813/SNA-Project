"""
utils/network_builder.py
========================
Builds the NetworkX graph from the raw node/edge data and computes SNA metrics.
"""

import networkx as nx
import pandas as pd
import numpy as np
from data.network_data import NODES, EDGES

# ── Community detection: try python-louvain, fall back to greedy modularity ──
try:
    import community as community_louvain  # python-louvain

    def _detect_communities(G):
        partition = community_louvain.best_partition(G, weight="weight", random_state=42)
        modularity = community_louvain.modularity(partition, G, weight="weight")
        return partition, modularity

except ImportError:
    # Built-in fallback: NetworkX greedy modularity (no extra install required)
    from networkx.algorithms.community import greedy_modularity_communities, modularity

    def _detect_communities(G):
        communities = list(greedy_modularity_communities(G, weight="weight"))
        partition = {}
        for i, comm in enumerate(communities):
            for node in comm:
                partition[node] = i
        mod = modularity(G, communities, weight="weight")
        return partition, mod


def build_graph() -> nx.Graph:
    """Construct the undirected weighted tourism network."""
    G = nx.Graph()

    for node in NODES:
        G.add_node(
            node["id"],
            label=node["label"],
            type=node["type"],
            lat=node["lat"],
            lon=node["lon"],
            description=node["description"],
            historical_period=node["historical_period"],
            significance=node["significance"],
            visitor_annual=node["visitor_annual"],
            tags=node["tags"],
            source=node["source"],
        )

    for edge in EDGES:
        # Some edges may reference a node ID that doesn't exist (e.g. the
        # intentional alias typo "thirunarur_temple" in the raw data).
        if G.has_node(edge["u"]) and G.has_node(edge["v"]):
            G.add_edge(
                edge["u"],
                edge["v"],
                type=edge["type"],
                weight=edge["weight"],
                distance_km=edge["distance_km"],
                reason=edge["reason"],
                source=edge["source"],
            )

    return G


def compute_metrics(G: nx.Graph) -> dict:
    """Compute a comprehensive set of SNA metrics."""
    metrics = {}

    # ── Centrality measures ─────────────────────────────────────────────────
    metrics["degree_centrality"] = nx.degree_centrality(G)
    metrics["betweenness_centrality"] = nx.betweenness_centrality(
        G, weight="weight", normalized=True
    )
    metrics["closeness_centrality"] = nx.closeness_centrality(G, distance=None)
    metrics["eigenvector_centrality"] = nx.eigenvector_centrality(
        G, max_iter=1000, weight="weight"
    )
    # PageRank (adapted for undirected tourism flow)
    metrics["pagerank"] = nx.pagerank(G, alpha=0.85, weight="weight")

    # ── Weighted degree (strength) ──────────────────────────────────────────
    metrics["strength"] = {
        node: sum(d["weight"] for _, _, d in G.edges(node, data=True))
        for node in G.nodes()
    }

    # ── Community detection (Louvain if available, else greedy modularity) ──
    partition, mod = _detect_communities(G)
    metrics["community"] = partition
    metrics["modularity"] = mod

    # ── Graph-level statistics ──────────────────────────────────────────────
    metrics["graph_stats"] = {
        "nodes": G.number_of_nodes(),
        "edges": G.number_of_edges(),
        "density": nx.density(G),
        "avg_clustering": nx.average_clustering(G, weight="weight"),
        "avg_degree": np.mean([d for _, d in G.degree()]),
        "num_communities": len(set(partition.values())),
        "modularity": metrics["modularity"],
        "is_connected": nx.is_connected(G),
    }

    # ── Centrality summary table ────────────────────────────────────────────
    rows = []
    node_labels = nx.get_node_attributes(G, "label")
    node_types = nx.get_node_attributes(G, "type")
    node_visitors = nx.get_node_attributes(G, "visitor_annual")

    for node in G.nodes():
        rows.append(
            {
                "id": node,
                "label": node_labels.get(node, node),
                "type": node_types.get(node, ""),
                "degree_centrality": round(metrics["degree_centrality"][node], 4),
                "betweenness_centrality": round(
                    metrics["betweenness_centrality"][node], 4
                ),
                "closeness_centrality": round(
                    metrics["closeness_centrality"][node], 4
                ),
                "eigenvector_centrality": round(
                    metrics["eigenvector_centrality"][node], 4
                ),
                "pagerank": round(metrics["pagerank"][node], 4),
                "strength": metrics["strength"][node],
                "community": partition[node],
                "visitor_annual": node_visitors.get(node, 0),
            }
        )

    metrics["centrality_df"] = pd.DataFrame(rows).sort_values(
        "betweenness_centrality", ascending=False
    )

    return metrics


def get_shortest_paths(G: nx.Graph, source: str, targets: list) -> dict:
    """Return shortest weighted paths from source to each target."""
    paths = {}
    for target in targets:
        if target == source:
            continue
        try:
            path = nx.shortest_path(G, source=source, target=target, weight=None)
            length = nx.shortest_path_length(
                G, source=source, target=target, weight=None
            )
            paths[target] = {"path": path, "hops": length}
        except nx.NetworkXNoPath:
            paths[target] = {"path": [], "hops": float("inf")}
    return paths


def generate_itinerary(
    G: nx.Graph,
    metrics: dict,
    interests: list,
    days: int,
    start_node: str = "rajagopalaswamy_temple",
) -> list:
    """
    Generate a day-by-day itinerary using network proximity and centrality.

    Algorithm:
      1. Filter candidate nodes by interest tags.
      2. Score each candidate by: betweenness_centrality + eigenvector_centrality
         + normalised visitor_annual.
      3. Greedily pick next site that is (a) highest score and (b) connected to
         the previous site within 2 hops, grouping into days of ~3 sites each.
    """
    from data.network_data import INTEREST_TAGS

    # Collect relevant tags
    relevant_tags = set()
    for interest in interests:
        relevant_tags.update(INTEREST_TAGS.get(interest, []))

    # Score nodes
    node_attrs = dict(G.nodes(data=True))
    max_visitors = max(a.get("visitor_annual", 1) for a in node_attrs.values()) or 1

    candidates = []
    for node, attrs in node_attrs.items():
        tags = set(attrs.get("tags", []))
        if not relevant_tags or tags & relevant_tags:  # intersection
            score = (
                metrics["betweenness_centrality"].get(node, 0) * 0.35
                + metrics["eigenvector_centrality"].get(node, 0) * 0.35
                + attrs.get("visitor_annual", 0) / max_visitors * 0.30
            )
            candidates.append((node, score))

    candidates.sort(key=lambda x: -x[1])

    # Build day-by-day schedule
    itinerary = []
    visited = set()
    current = start_node
    visited.add(current)

    sites_per_day = 3
    total_sites = days * sites_per_day

    # Always start with the start_node on day 1
    day_sites = [start_node]

    for node, _ in candidates:
        if node in visited:
            continue
        if len(day_sites) >= sites_per_day:
            itinerary.append(day_sites)
            if len(itinerary) >= days:
                break
            day_sites = []
        day_sites.append(node)
        visited.add(node)
        current = node

    if day_sites and len(itinerary) < days:
        itinerary.append(day_sites)

    # Pad with top unvisited if needed
    while len(itinerary) < days:
        itinerary.append([])

    return itinerary[:days]


def get_node_info(G: nx.Graph, node_id: str, metrics: dict) -> dict:
    """Return enriched info about a single node."""
    attrs = dict(G.nodes[node_id])
    return {
        **attrs,
        "degree": G.degree(node_id),
        "strength": metrics["strength"].get(node_id, 0),
        "betweenness_centrality": round(
            metrics["betweenness_centrality"].get(node_id, 0), 4
        ),
        "closeness_centrality": round(
            metrics["closeness_centrality"].get(node_id, 0), 4
        ),
        "eigenvector_centrality": round(
            metrics["eigenvector_centrality"].get(node_id, 0), 4
        ),
        "pagerank": round(metrics["pagerank"].get(node_id, 0), 4),
        "community": metrics["community"].get(node_id, -1),
        "neighbors": list(G.neighbors(node_id)),
    }
