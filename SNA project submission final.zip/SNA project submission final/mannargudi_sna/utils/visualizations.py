"""
utils/visualizations.py
=======================
All Plotly-based interactive visualizations for the Mannargudi SNA project.
"""

import plotly.graph_objects as go
import plotly.express as px
import networkx as nx
import pandas as pd
import numpy as np
from data.network_data import TYPE_COLORS


# ── Colour helpers ────────────────────────────────────────────────────────────
COMMUNITY_PALETTE = [
    "#E07B39", "#4A90D9", "#6AB187", "#9B59B6",
    "#F1C40F", "#E74C3C", "#1ABC9C", "#E67E22",
]

EDGE_TYPE_COLORS = {
    "proximity": "#95A5A6",
    "road_transport": "#3498DB",
    "thematic_pilgrimage": "#E07B39",
    "thematic_cultural": "#9B59B6",
    "ecological": "#6AB187",
    "cultural_landscape": "#F39C12",
}


def _spring_positions(G: nx.Graph, seed: int = 42) -> dict:
    """Compute spring-layout positions (2D)."""
    return nx.spring_layout(G, weight="weight", seed=seed, k=2.5)


def _geo_positions(G: nx.Graph) -> dict:
    """Use lat/lon as positions (lon→x, lat→y) for geographic layout."""
    attrs = dict(G.nodes(data=True))
    return {
        node: (attrs[node]["lon"], attrs[node]["lat"])
        for node in G.nodes()
        if "lon" in attrs[node]
    }


def _make_edge_traces(G: nx.Graph, pos: dict, color_by: str = "type") -> list:
    """Return a list of scatter traces (one per edge) for Plotly."""
    traces = []
    for u, v, data in G.edges(data=True):
        if u not in pos or v not in pos:
            continue
        x0, y0 = pos[u]
        x1, y1 = pos[v]
        etype = data.get("type", "road_transport")
        color = EDGE_TYPE_COLORS.get(etype, "#BDC3C7")
        weight = data.get("weight", 1)
        traces.append(
            go.Scatter(
                x=[x0, x1, None],
                y=[y0, y1, None],
                mode="lines",
                line=dict(width=max(0.5, weight * 0.4), color=color),
                hoverinfo="text",
                text=f"{data.get('reason','')}<br>Distance: {data.get('distance_km','')} km<br>Type: {etype}",
                showlegend=False,
            )
        )
    return traces


def network_overview(G: nx.Graph, metrics: dict, layout: str = "spring") -> go.Figure:
    """
    Full interactive network graph coloured by node type.
    Node size ∝ betweenness centrality.
    """
    pos = _geo_positions(G) if layout == "geographic" else _spring_positions(G)

    edge_traces = _make_edge_traces(G, pos)

    node_x, node_y, node_text, node_color, node_size, node_label = [], [], [], [], [], []
    node_attrs = dict(G.nodes(data=True))
    bc = metrics["betweenness_centrality"]

    for node in G.nodes():
        if node not in pos:
            continue
        x, y = pos[node]
        attrs = node_attrs[node]
        node_x.append(x)
        node_y.append(y)
        node_color.append(TYPE_COLORS.get(attrs.get("type", ""), "#95A5A6"))
        node_size.append(15 + bc.get(node, 0) * 120)
        node_label.append(attrs.get("label", node))
        node_text.append(
            f"<b>{attrs.get('label', node)}</b><br>"
            f"Type: {attrs.get('type', '')}<br>"
            f"Betweenness: {bc.get(node, 0):.3f}<br>"
            f"Community: {metrics['community'].get(node, '')}<br>"
            f"Annual visitors: {attrs.get('visitor_annual', 'N/A'):,}<br>"
            f"Period: {attrs.get('historical_period', '')}"
        )

    node_trace = go.Scatter(
        x=node_x,
        y=node_y,
        mode="markers+text",
        text=node_label,
        textposition="top center",
        textfont=dict(size=8, color="#2C3E50"),
        hovertext=node_text,
        hoverinfo="text",
        marker=dict(
            color=node_color,
            size=node_size,
            line=dict(width=1.5, color="#FFFFFF"),
            opacity=0.92,
        ),
        showlegend=False,
    )

    # Legend traces (one per type)
    legend_traces = []
    for ntype, color in TYPE_COLORS.items():
        legend_traces.append(
            go.Scatter(
                x=[None],
                y=[None],
                mode="markers",
                marker=dict(size=10, color=color),
                name=ntype.replace("_", " ").title(),
                showlegend=True,
            )
        )

    fig = go.Figure(data=edge_traces + [node_trace] + legend_traces)
    fig.update_layout(
        title="Mannargudi Tourism Network — Node Type View",
        title_font_size=16,
        hovermode="closest",
        margin=dict(l=20, r=20, t=60, b=20),
        paper_bgcolor="#F8F9FA",
        plot_bgcolor="#F8F9FA",
        xaxis=dict(showgrid=False, zeroline=False, showticklabels=False),
        yaxis=dict(showgrid=False, zeroline=False, showticklabels=False),
        legend=dict(
            title="Site Type",
            bgcolor="rgba(255,255,255,0.85)",
            bordercolor="#DEE2E6",
            borderwidth=1,
        ),
        height=620,
    )
    return fig


def community_view(G: nx.Graph, metrics: dict) -> go.Figure:
    """Network coloured by detected community (Louvain)."""
    pos = _spring_positions(G)
    edge_traces = _make_edge_traces(G, pos)

    partition = metrics["community"]
    num_communities = len(set(partition.values()))

    node_x, node_y, node_text, node_color, node_size, node_label = [], [], [], [], [], []
    node_attrs = dict(G.nodes(data=True))
    bc = metrics["betweenness_centrality"]

    for node in G.nodes():
        if node not in pos:
            continue
        x, y = pos[node]
        attrs = node_attrs[node]
        comm = partition.get(node, 0)
        node_x.append(x)
        node_y.append(y)
        node_color.append(COMMUNITY_PALETTE[comm % len(COMMUNITY_PALETTE)])
        node_size.append(15 + bc.get(node, 0) * 120)
        node_label.append(attrs.get("label", node))
        node_text.append(
            f"<b>{attrs.get('label', node)}</b><br>"
            f"Community: {comm}<br>"
            f"Type: {attrs.get('type', '')}<br>"
            f"Betweenness: {bc.get(node, 0):.3f}"
        )

    node_trace = go.Scatter(
        x=node_x, y=node_y,
        mode="markers+text",
        text=node_label,
        textposition="top center",
        textfont=dict(size=8, color="#2C3E50"),
        hovertext=node_text,
        hoverinfo="text",
        marker=dict(
            color=node_color, size=node_size,
            line=dict(width=1.5, color="#FFFFFF"), opacity=0.92,
        ),
        showlegend=False,
    )

    # Community legend
    legend_traces = []
    for i in range(num_communities):
        legend_traces.append(
            go.Scatter(
                x=[None], y=[None], mode="markers",
                marker=dict(size=10, color=COMMUNITY_PALETTE[i % len(COMMUNITY_PALETTE)]),
                name=f"Community {i}",
                showlegend=True,
            )
        )

    fig = go.Figure(data=edge_traces + [node_trace] + legend_traces)
    fig.update_layout(
        title=f"Community Structure — {num_communities} communities detected (Louvain, modularity={metrics['modularity']:.3f})",
        title_font_size=15,
        hovermode="closest",
        margin=dict(l=20, r=20, t=60, b=20),
        paper_bgcolor="#F8F9FA",
        plot_bgcolor="#F8F9FA",
        xaxis=dict(showgrid=False, zeroline=False, showticklabels=False),
        yaxis=dict(showgrid=False, zeroline=False, showticklabels=False),
        height=620,
    )
    return fig


def centrality_bar(metrics: dict, centrality_type: str = "betweenness_centrality") -> go.Figure:
    """Horizontal bar chart of top-N nodes by chosen centrality."""
    df = metrics["centrality_df"].sort_values(centrality_type, ascending=True).tail(15)
    colors = [TYPE_COLORS.get(t, "#95A5A6") for t in df["type"]]

    fig = go.Figure(
        go.Bar(
            x=df[centrality_type],
            y=df["label"],
            orientation="h",
            marker_color=colors,
            hovertemplate="<b>%{y}</b><br>Score: %{x:.4f}<extra></extra>",
        )
    )
    title_map = {
        "betweenness_centrality": "Betweenness Centrality (flow control)",
        "closeness_centrality": "Closeness Centrality (accessibility)",
        "eigenvector_centrality": "Eigenvector Centrality (influence)",
        "degree_centrality": "Degree Centrality (connectivity)",
        "pagerank": "PageRank (importance)",
    }
    fig.update_layout(
        title=title_map.get(centrality_type, centrality_type),
        xaxis_title="Score",
        yaxis_title="",
        height=480,
        margin=dict(l=200, r=30, t=60, b=40),
        paper_bgcolor="#F8F9FA",
        plot_bgcolor="white",
    )
    return fig


def geographic_map(G: nx.Graph, metrics: dict, highlight_path: list = None) -> go.Figure:
    """
    Plotly map using lat/lon. Nodes sized by PageRank.
    Optionally highlight a path.
    """
    node_attrs = dict(G.nodes(data=True))
    pr = metrics["pagerank"]
    max_pr = max(pr.values()) or 1

    lats, lons, texts, colors, sizes = [], [], [], [], []
    for node in G.nodes():
        attrs = node_attrs[node]
        lats.append(attrs["lat"])
        lons.append(attrs["lon"])
        sizes.append(10 + (pr.get(node, 0) / max_pr) * 30)
        colors.append(TYPE_COLORS.get(attrs.get("type", ""), "#95A5A6"))
        texts.append(
            f"<b>{attrs.get('label', node)}</b><br>"
            f"Type: {attrs.get('type', '')}<br>"
            f"PageRank: {pr.get(node, 0):.4f}<br>"
            f"Annual visitors: {attrs.get('visitor_annual', 'N/A'):,}"
        )

    fig = go.Figure()

    # Draw edges as lines on map
    for u, v, data in G.edges(data=True):
        if u not in node_attrs or v not in node_attrs:
            continue
        ua, va = node_attrs[u], node_attrs[v]
        etype = data.get("type", "road_transport")
        ecolor = EDGE_TYPE_COLORS.get(etype, "#BDC3C7")
        fig.add_trace(
            go.Scattergeo(
                lat=[ua["lat"], va["lat"]],
                lon=[ua["lon"], va["lon"]],
                mode="lines",
                line=dict(width=data.get("weight", 1) * 0.3, color=ecolor),
                opacity=0.5,
                showlegend=False,
                hoverinfo="skip",
            )
        )

    # Draw nodes
    fig.add_trace(
        go.Scattergeo(
            lat=lats,
            lon=lons,
            mode="markers",
            marker=dict(
                size=sizes,
                color=colors,
                line=dict(width=1, color="white"),
                opacity=0.9,
            ),
            hovertext=texts,
            hoverinfo="text",
            showlegend=False,
        )
    )

    # Highlight path if given
    if highlight_path and len(highlight_path) > 1:
        path_lats = [node_attrs[n]["lat"] for n in highlight_path if n in node_attrs]
        path_lons = [node_attrs[n]["lon"] for n in highlight_path if n in node_attrs]
        fig.add_trace(
            go.Scattergeo(
                lat=path_lats,
                lon=path_lons,
                mode="lines+markers",
                line=dict(width=4, color="#E74C3C"),
                marker=dict(size=12, color="#E74C3C", symbol="star"),
                name="Selected Path",
                showlegend=True,
            )
        )

    fig.update_geos(
        scope="asia",
        resolution=50,
        center=dict(lat=10.65, lon=79.55),
        lataxis_range=[10.0, 11.5],
        lonaxis_range=[78.8, 80.2],
        showland=True,
        landcolor="#EEF2E6",
        showcoastlines=True,
        coastlinecolor="#B8C9A3",
        showrivers=True,
        rivercolor="#7FB3D3",
        showcountries=True,
    )
    fig.update_layout(
        title="Geographic Tourism Network — Thiruvarur District & Surroundings",
        height=580,
        margin=dict(l=10, r=10, t=60, b=10),
        paper_bgcolor="#F8F9FA",
    )
    return fig


def radar_chart(node_data: dict) -> go.Figure:
    """Radar chart of centrality metrics for a selected node."""
    categories = [
        "Degree", "Betweenness", "Closeness", "Eigenvector", "PageRank"
    ]
    values = [
        node_data.get("degree_centrality", node_data.get("degree", 0)),
        node_data.get("betweenness_centrality", 0),
        node_data.get("closeness_centrality", 0),
        node_data.get("eigenvector_centrality", 0),
        node_data.get("pagerank", 0),
    ]
    # Normalise to 0-1
    max_val = max(values) or 1
    values_norm = [v / max_val for v in values]

    fig = go.Figure(
        go.Scatterpolar(
            r=values_norm + [values_norm[0]],
            theta=categories + [categories[0]],
            fill="toself",
            fillcolor="rgba(224,123,57,0.3)",
            line=dict(color="#E07B39", width=2),
        )
    )
    fig.update_layout(
        polar=dict(
            radialaxis=dict(visible=True, range=[0, 1]),
            angularaxis=dict(tickfont=dict(size=11)),
        ),
        title=f"Centrality Profile",
        height=350,
        margin=dict(l=40, r=40, t=60, b=40),
        paper_bgcolor="#F8F9FA",
    )
    return fig


def itinerary_flow(G: nx.Graph, itinerary: list, metrics: dict) -> go.Figure:
    """Sankey / path diagram for the generated itinerary."""
    node_attrs = dict(G.nodes(data=True))
    pos = _spring_positions(G)

    fig = go.Figure()
    all_visited = [n for day in itinerary for n in day if n in pos]

    # Draw all edges (faded)
    for u, v, data in G.edges(data=True):
        if u not in pos or v not in pos:
            continue
        x0, y0 = pos[u]; x1, y1 = pos[v]
        fig.add_trace(go.Scatter(
            x=[x0, x1, None], y=[y0, y1, None],
            mode="lines",
            line=dict(width=0.5, color="#E0E0E0"),
            hoverinfo="none", showlegend=False,
        ))

    day_colors = ["#E07B39", "#4A90D9", "#6AB187", "#9B59B6", "#F1C40F", "#E74C3C", "#1ABC9C"]

    for day_idx, day_nodes in enumerate(itinerary):
        color = day_colors[day_idx % len(day_colors)]
        valid = [n for n in day_nodes if n in pos]

        # Draw path between consecutive sites
        for i in range(len(valid) - 1):
            x0, y0 = pos[valid[i]]; x1, y1 = pos[valid[i + 1]]
            fig.add_trace(go.Scatter(
                x=[x0, x1, None], y=[y0, y1, None],
                mode="lines",
                line=dict(width=3, color=color),
                hoverinfo="none", showlegend=False,
            ))

        # Draw nodes
        for node in valid:
            x, y = pos[node]
            attrs = node_attrs.get(node, {})
            fig.add_trace(go.Scatter(
                x=[x], y=[y],
                mode="markers+text",
                marker=dict(size=20, color=color, line=dict(width=2, color="white")),
                text=[attrs.get("label", node)],
                textposition="top center",
                textfont=dict(size=8),
                hovertext=f"<b>Day {day_idx+1}</b><br>{attrs.get('label', node)}<br>{attrs.get('description', '')[:80]}...",
                hoverinfo="text",
                showlegend=(node == valid[0]),
                name=f"Day {day_idx+1}",
            ))

    fig.update_layout(
        title="Your Personalised Itinerary Network Path",
        hovermode="closest",
        xaxis=dict(showgrid=False, zeroline=False, showticklabels=False),
        yaxis=dict(showgrid=False, zeroline=False, showticklabels=False),
        paper_bgcolor="#F8F9FA",
        plot_bgcolor="#F8F9FA",
        height=540,
        margin=dict(l=20, r=20, t=60, b=20),
    )
    return fig


def visitors_scatter(metrics: dict) -> go.Figure:
    """Scatter: betweenness centrality vs annual visitors, sized by PageRank."""
    df = metrics["centrality_df"].copy()
    max_pr = df["pagerank"].max() or 1
    sizes = (df["pagerank"] / max_pr * 40 + 8).tolist()

    from data.network_data import TYPE_COLORS
    colors = [TYPE_COLORS.get(t, "#95A5A6") for t in df["type"]]

    fig = go.Figure(
        go.Scatter(
            x=df["betweenness_centrality"],
            y=df["visitor_annual"],
            mode="markers+text",
            text=df["label"],
            textposition="top center",
            textfont=dict(size=8),
            marker=dict(size=sizes, color=colors, line=dict(width=1, color="white"), opacity=0.85),
            hovertemplate=(
                "<b>%{text}</b><br>"
                "Betweenness: %{x:.4f}<br>"
                "Visitors/yr: %{y:,}<extra></extra>"
            ),
        )
    )
    fig.update_layout(
        title="Betweenness Centrality vs Annual Visitors",
        xaxis_title="Betweenness Centrality (network gateway importance)",
        yaxis_title="Estimated Annual Visitors",
        height=420,
        paper_bgcolor="#F8F9FA",
        plot_bgcolor="white",
        margin=dict(l=60, r=30, t=60, b=60),
    )
    return fig
